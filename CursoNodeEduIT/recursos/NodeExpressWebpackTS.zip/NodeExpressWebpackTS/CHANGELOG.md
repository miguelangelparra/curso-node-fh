<a name="1.0.0"></a>
# 1.0.0 (2018-01-01)


### Features

* **build:** add webpack ([800180b](https://github.com/wzr1337/node_express_webpack_starter/commit/800180b))
* **general:** add webpack watch server ([1661a53](https://github.com/wzr1337/node_express_webpack_starter/commit/1661a53))



