console.log('******************')

console.log('Hola soy index.js!!!')

function dobleDe(a) {
    return 2*a
}

var num = 7
console.log('El cuadruple de ' + num + ' es ' + dobleDe(dobleDe(num)))

console.log('******************')